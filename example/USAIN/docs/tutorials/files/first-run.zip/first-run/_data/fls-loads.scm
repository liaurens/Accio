MARKOV DIRECTORY : ./Markov/

 BHawC channel reference file (sel):
+==============================================================================+
     BHawC command file :      bhr_EA3_DLC12_040001_354000_00001_#Swell015_mSus.dat  2021.07.22  01:15:41
 Channel reference file : SSSR_bhr_EA3_DLC12_040001_354000_00001_#Swell015_mSus.sel  2021.07.27  15:59:35
            Result file : SSSR_bhr_EA3_DLC12_040001_354000_00001_#Swell015_mSus.dat  2021.07.27  15:59:35

+==============================================================================+
  Scans    Channels    Time [sec]                Coordinate convention: Siemens
  15000       4        600.000

  Channel   Variable description                 Label           Units

     1      Time                                 t               [s]
     2      Mt_150 e19n2                         Mt_x (-125.52)  [kNm]
     3      Mt_120 e.9n1                         Mt_x (-57.96)   [kNm]
     4      Mt_120 e.1n1                         Mt_x (  0.00)   [kNm]
 BHawC channel reference file (sel):
